# TapPilot Android Auto Clicker (starter project)

This is a starter Android project for a configurable accessibility-based tap utility.
It is provided as source code; it is **not a compiled APK**.

## Features in this starter
- Tap at one or more fixed screen coordinates (format `x,y;x,y`)
- Base interval in milliseconds
- Optional random interval min/max
- Floating start/stop overlay
- Volume-up key toggles tapping when the accessibility service is enabled
- Multiple simultaneous gesture strokes (up to 10 coordinates)

## Build a debug APK for free with GitHub Actions
1. Create a GitHub repository and upload this project folder contents.
2. Open the repository's **Actions** tab.
3. Select **Build TapPilot APK** and press **Run workflow**.
4. When it completes, open the run and download the `TapPilot-debug-apk` artifact.
5. Extract `app-debug.apk` and install it on your Android phone.

## First-run setup
1. Open TapPilot.
2. Press "Open accessibility service settings" and enable TapPilot.
3. Return to TapPilot; set coordinates and interval, then save.
4. For the floating button, enable "Display over other apps" when asked.
5. Start/stop using the floating control or volume-up key.

## Important limitations
- The coordinate fields currently require manual screen coordinates; a coordinate-picker overlay is not yet included.
- The volume-up shortcut can conflict with the phone's volume behavior, and Android/device OEMs may restrict key filtering.
- Gesture-based simultaneous taps are subject to Android's accessibility gesture implementation and game compatibility.
- Many games prohibit automation. Use only where allowed; this app does not bypass game anti-cheat.
- Test on non-sensitive screens first. Accessibility permissions are powerful and should be enabled only for software you trust.

## Technical note
This starter targets Android API 28 for broad compatibility and uses compile SDK 35. Build toolchain compatibility may need adjustment based on the IDE/build environment.
