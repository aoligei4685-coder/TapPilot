package com.example.tappilot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlin.random.Random

class TapAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    companion object {
        @Volatile private var instance: TapAccessibilityService? = null
        fun toggleTapping() { instance?.toggle() }
        fun stopTapping() { instance?.stop() }
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_UP && event.keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            toggle()
            return true
        }
        return super.onKeyEvent(event)
    }

    private fun toggle() {
        if (running) stop() else start()
    }

    private fun start() {
        if (running) return
        running = true
        performLoop()
    }

    private fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun performLoop() {
        if (!running) return
        val prefs = getSharedPreferences("tap_settings", MODE_PRIVATE)
        val base = prefs.getLong("interval", 100L).coerceAtLeast(20L)
        val min = prefs.getLong("randomMin", 0L).coerceAtLeast(0L)
        val max = prefs.getLong("randomMax", 0L).coerceAtLeast(min)
        val delay = if (min > 0 && max >= min) Random.nextLong(min, max + 1) else base
        val coordinateText = prefs.getString("points", "500,900") ?: "500,900"
        val coords = coordinateText.split(";").mapNotNull { part ->
            val pair = part.trim().split(",")
            if (pair.size != 2) null else {
                val x = pair[0].trim().toFloatOrNull()
                val y = pair[1].trim().toFloatOrNull()
                if (x != null && y != null) Pair(x, y) else null
            }
        }.take(10)

        if (coords.isNotEmpty()) {
            val builder = GestureDescription.Builder()
            coords.forEach { (x, y) ->
                val path = Path().apply { moveTo(x, y); lineTo(x, y) }
                builder.addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            }
            dispatchGesture(builder.build(), null, null)
        }
        handler.postDelayed({ performLoop() }, delay)
    }

    override fun onDestroy() {
        stop()
        instance = null
        super.onDestroy()
    }
}
