package com.example.tappilot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var interval: EditText
    private lateinit var randomMin: EditText
    private lateinit var randomMax: EditText
    private lateinit var points: EditText
    private lateinit var overlayButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.rgb(248, 249, 252))
        }
        val title = TextView(this).apply {
            text = "TapPilot 连点器"
            textSize = 25f
            setTextColor(Color.rgb(30, 40, 60))
        }
        layout.addView(title)
        layout.addView(TextView(this).apply {
            text = "使用说明：设置点击参数后，启动无障碍服务。坐标以屏幕左上角为原点。"
            textSize = 14f
            setPadding(0, 12, 0, 16)
        })

        interval = field(layout, "基础间隔（毫秒）", "100")
        randomMin = field(layout, "随机最小间隔（毫秒，0=关闭）", "0")
        randomMax = field(layout, "随机最大间隔（毫秒）", "0")
        points = field(layout, "点击点坐标：x,y；多个点用分号隔开", "500,900")

        val apply = Button(this).apply {
            text = "保存设置"
            setOnClickListener { saveSettings(); toast("设置已保存") }
        }
        layout.addView(apply)

        val accessibility = Button(this).apply {
            text = "打开无障碍服务设置"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(accessibility)

        val overlay = Button(this).apply {
            text = "开启悬浮控制按钮"
            setOnClickListener {
                saveSettings()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    toast("悬浮按钮已开启")
                }
            }
        }
        layout.addView(overlay)

        val stop = Button(this).apply {
            text = "停止点击 / 关闭悬浮窗"
            setOnClickListener {
                TapAccessibilityService.stopTapping()
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }
        layout.addView(stop)

        layout.addView(TextView(this).apply {
            text = "快捷键：无障碍服务启用后，按音量上键开始/停止。\\n注意：游戏可能禁止自动化操作；请遵守游戏规则。"
            textSize = 13f
            setPadding(0, 18, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun field(parent: LinearLayout, label: String, value: String): EditText {
        parent.addView(TextView(this).apply { text = label; textSize = 14f; setPadding(0, 8, 0, 4) })
        val edit = EditText(this).apply {
            setSingleLine(true); setText(value); textSize = 16f
        }
        parent.addView(edit)
        return edit
    }

    private fun saveSettings() {
        val prefs = getSharedPreferences("tap_settings", MODE_PRIVATE)
        prefs.edit()
            .putLong("interval", interval.text.toString().toLongOrNull()?.coerceAtLeast(20L) ?: 100L)
            .putLong("randomMin", randomMin.text.toString().toLongOrNull()?.coerceAtLeast(0L) ?: 0L)
            .putLong("randomMax", randomMax.text.toString().toLongOrNull()?.coerceAtLeast(0L) ?: 0L)
            .putString("points", points.text.toString())
            .apply()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
